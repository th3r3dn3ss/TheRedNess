var c1 = "Carsoap: ";
var m = "Money: ";
var w = "Wax: ";
var wo = "Workers: ";
var ws = "Wheelsoap: ";
var ic = "Interior Cleaner: ";
var lc = "Leather Cleaner: ";
var lcon = "Leather Conditioner: ";
var products = {
  carfinished: (this.cardone)
};
this.money = 1000;
this.stalls = 0;
this.workers = 0;
this.carsoap = 0;
this.wax = 0;
this.wheelsoap = 0;
this.interiorcleaner = 0;
this.leathercleaner = 0;
this.leatherconditioner = 0;
this.carvar = Math.floor(Math.random() * 4);
this.moneyAlert = false;
this.materialAlert = false;
this.buystalls = function() {
  if (checkcost(700)) {
    this.stalls += 1;
    this.money -= 700;
  }
};
this.buyworker = function() {
  if (checkcost(100)) {
    this.workers += 1;
    this.money -= 100;
  }
};
this.buycarsoap = function() {
  
    this.carsoap += 1;
    this.money -= 10;
  };
this.buywax = function() {
  if (checkcost(5)) {
    this.wax += 1;
    this.money -= 5;
  }
};
this.buywheelsoap = function() {
  if (checkcost(5)) {
    this.lemons += 1;
    this.money -= 5;
  }
};
this.buyinterorcleaner = function() {
  if (checkcost(5)) {
    this.interiorcleaner += 1;
    this.money -= 1;
  }
};
this.buyleathercleaner = function() {
  if (checkcost(5)) {
    this.leathercleaner += 1;
    this.money -= 5;
  }
};
this.buyleatherconditioner = function() {
  if (checkcost(10)) {
    this.leatherconditioner += 1;
    this.money -= 10;
  }
};
this.cc = function() {
  if (this.carvar = 0) {
    (this.lc = false) && (this.pc = false);
  } else if (this.carvar = 1) {
    (this.lc = true) && (this.pc = false);
  } else if (this.carvar = 2) {
    (this.lc = false) && (this.pc = true);
  } else if (this.carvar = 3) {
    (this.lc = true) && (this.pc = true);
  }
};
this.cardone = function() {
  if (this.carvar = 0) {
    this.money += 300;
  } else if (this.carvar = 1) {
    this.money += 200;
  } else if (this.carvar = 2) {
    this.money += 250;
  }
};

var checkcost = function(cost) {
  if (_this.money >= cost) {
    return true;
  } else {
    return false;
  }
};
var checkIngredients = function(product) {
  if (product === products.carfinished) {
    if (_this.carsoap >= carsoap.products && _this.wax >= wax.products && _this.wheelsoap >= wheelsoap.products && _this.interiorcleaner >= interiorcleaner.products && _this.leathercleaner >= leathercleaner.products && _stalls.carsoap >= stalls.products) {
      _this.materialAlert = false;
      return true;
    } else {
      _this.materialAlert = true;
    }
  }
};